package com.raishxn.gtna.utils;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraftforge.registries.ForgeRegistries;

import com.raishxn.gtna.GTNACORE;

public class Registries {

    public static Item getItem(String s) {
        Item i = ForgeRegistries.ITEMS.getValue(ResourceLocation.tryParse(s));
        if (i == null || i == Items.AIR) {
            GTNACORE.LOGGER.atError().log("Item with ID {}not found", s);
            return Items.BARRIER;
        }
        return i;
    }

    public static ItemStack getItemStack(String s) {
        return getItemStack(s, 1);
    }

    public static ItemStack getItemStack(String s, int a) {
        return new ItemStack(getItem(s), a);
    }

    public static Block getBlock(String s) {
        Block b = ForgeRegistries.BLOCKS.getValue(ResourceLocation.tryParse(s));
        if (b == null || b == Blocks.AIR) {
            GTNACORE.LOGGER.atError().log("No block with ID {}found", s);
            return Blocks.BARRIER;
        }
        return b;
    }

    public static Fluid getFluid(String s) {
        Fluid f = ForgeRegistries.FLUIDS.getValue(ResourceLocation.tryParse(s));
        if (f == null || f == Fluids.EMPTY) {
            GTNACORE.LOGGER.atError().log("No fluid with ID {}found", s);
            return Fluids.WATER;
        }
        return f;
    }

    public static ResourceKey<Level> getDimension(String s) {
        ResourceLocation loc = ResourceLocation.tryParse(s);
        if (loc == null) throw new IllegalArgumentException("Invalid dimension: " + s);
        return ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION, loc);
    }
}
